package com.capgemini.mps.service;

public interface IPurchaseService {

}

package com.capgemini.mps.service;

public class PurchaseServiceImpl {

}

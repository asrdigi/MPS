package com.capgemini.mps.dao;

public class PurchaseDaoImpl implements IPurchaseDAO{

	@Override
	public Integer addPurchaseDetails(String name, String emailId, Long phoneNumber, Integer mobileId) {
		// TODO Auto-generated method stub
		return null;
	}

}

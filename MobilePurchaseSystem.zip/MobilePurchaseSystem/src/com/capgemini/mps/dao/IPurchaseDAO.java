package com.capgemini.mps.dao;

public interface IPurchaseDAO {
	public Integer addPurchaseDetails(String name, String emailId,Long phoneNumber,Integer mobileId);
}
